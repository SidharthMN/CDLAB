#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_INPUT 100 // Increased buffer size

char input[MAX_INPUT];
int i, error;

void E();
void Eprime();
void T();
void Tprime();
void F();

int main() {
    printf("\nGrammar without left recursion:\n");
    printf("\tE  -> T E'\n");
    printf("\tE' -> + T E' | ε\n");
    printf("\tT  -> F T'\n");
    printf("\tT' -> * F T' | ε\n");
    printf("\tF  -> (E) | id\n");

    printf("\nEnter an arithmetic expression (e.g., a+a*a): ");
    if (fgets(input, MAX_INPUT, stdin) == NULL) {
        printf("Error reading input.\n");
        return 1;
    }
    // Remove trailing newline from fgets
    input[strcspn(input, "\n")] = '\0';

    i = 0;
    error = 0;
    E();

    if (i == strlen(input) && error == 0)
        printf("\nAccepted...!!!\n");
    else
        printf("\nRejected...!!! Reason: %s\n",
               error ? "Invalid syntax" : "Incomplete expression");

    return 0;
}

void E() {
    T();
    Eprime();
}

void Eprime() {
    // Skip whitespace
    while (input[i] == ' ') i++;
    if (input[i] == '+') {
        i++;
        while (input[i] == ' ') i++; // Skip whitespace after +
        T();
        Eprime();
    }
}

void T() {
    F();
    Tprime();
}

void Tprime() {
    // Skip whitespace
    while (input[i] == ' ') i++;
    if (input[i] == '*') {
        i++;
        while (input[i] == ' ') i++; // Skip whitespace after *
        F();
        Tprime();
    }
}

void F() {
    // Skip whitespace
    while (input[i] == ' ') i++;
    if (isalpha(input[i])) { // Restrict id to letters
        i++;
    } else if (input[i] == '(') {
        i++;
        while (input[i] == ' ') i++; // Skip whitespace
        E();
        while (input[i] == ' ') i++; // Skip whitespace
        if (input[i] == ')')
            i++;
        else {
            error = 1;
            printf("Error: Missing closing parenthesis\n");
        }
    } else {
        error = 1;
        printf("Error: Expected identifier or '('\n");
    }
}
