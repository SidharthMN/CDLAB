#include<stdio.h>
//single comment chewk
void main()
{
int c=55; //test2
/* this is another test 
for multiline
comment*/
int a=6;
if(a==c)
printf("a==c!");
}

