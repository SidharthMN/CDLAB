#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int n, m = 0, p_i = 0, j = 0;
char a[10][10], f[10][10];
void first(char c);
void follow(char c);
int count;

int main() {
    int i, z;
    char c, ch;
    printf("Enter the no of productions: ");
    scanf("%d", &n);
    printf("Enter the %d productions: \n", n);
    for (i = 0; i < n; i++)
        scanf("%s%c", a[i], &ch);

    do {
        p_i = 0;
        printf("\nEnter an element (to find first & follow): ");
        scanf(" %c", &c);

        first(c);
        printf("First(%c) = {", c);
        for (i = 0; i < p_i; i++)
            printf("%c", f[1][i]);
        printf("}\n");

        strcpy(f[1], " ");
        p_i = 0;
        follow(c);
        printf("Follow(%c) = {", c);
        for (i = 0; i < p_i; i++)
            printf("%c", f[1][i]);
        printf("}\n");

        printf("Continue(0/1)? ");
        scanf("%d", &z);
    } while (z == 1);

    return 0;
}

void first(char c) {
    int k;
    if (!isupper(c))
        f[1][p_i++] = c;
    for (k = 0; k < n; k++) {
        if (a[k][0] == c) {
            if (a[k][2] == '$')
                follow(a[k][0]);
            else if (islower(a[k][2]))
                f[1][p_i++] = a[k][2];
            else
                first(a[k][2]);
        }
    }
}

void follow(char c) {
    if (a[0][0] == c)
        f[1][p_i++] = '$';
    for (int i = 0; i < n; i++) {
        for (j = 2; j < strlen(a[i]); j++) {
            if (a[i][j] == c) {
                if (a[i][j + 1] != '\0')
                    first(a[i][j + 1]);
                if (a[i][j + 1] == '\0' && a[i][0] != c)
                    follow(a[i][0]);
            }
        }
    }
}

