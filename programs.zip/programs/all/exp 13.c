#include <stdio.h>
#include <string.h>

char op[3], arg1[6], arg2[6], result[6];

void main() {
    FILE *fp1, *fp2;
    fp1 = fopen("input.txt", "r");
    if (fp1 == NULL) {
        perror("Error opening input file");
        return;
    }
    fp2 = fopen("output.txt", "w");
    if (fp2 == NULL) {
        perror("Error opening output file");
        fclose(fp1);
        return;
    }

    while (fscanf(fp1, "%2s%5s%5s%5s", op, arg1, arg2, result) == 4) {
        if (strcmp(op, "+") == 0) {
            fprintf(fp2, "\nMOV R0,%s", arg1);
            fprintf(fp2, "\nADD R0,%s", arg2);
            fprintf(fp2, "\nMOV %s,R0", result);
        }
        else if (strcmp(op, "*") == 0) {
            fprintf(fp2, "\nMOV R0,%s", arg1);
            fprintf(fp2, "\nMUL R0,%s", arg2);
            fprintf(fp2, "\nMOV %s,R0", result);
        }
        else if (strcmp(op, "-") == 0) {
            fprintf(fp2, "\nMOV R0,%s", arg1);
            fprintf(fp2, "\nSUB R0,%s", arg2);
            fprintf(fp2, "\nMOV %s,R0", result);
        }
        else if (strcmp(op, "/") == 0) {
            fprintf(fp2, "\nMOV R0,%s", arg1);
            fprintf(fp2, "\nDIV R0,%s", arg2);
            fprintf(fp2, "\nMOV %s,R0", result);
        }
        else if (strcmp(op, "=") == 0) {
            fprintf(fp2, "\nMOV R0,%s", arg1);
            fprintf(fp2, "\nMOV %s,R0", result);
        }
    }

    fclose(fp1);
    fclose(fp2);
}

