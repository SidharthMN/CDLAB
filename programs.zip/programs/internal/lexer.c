#include <stdio.h>
#include <ctype.h>
#include <string.h>

#define MAX_TOKEN 100

typedef enum { KEYWORD, IDENTIFIER, NUMBER, OPERATOR, PUNCTUATION } TokenType;
typedef struct { TokenType type; char value[MAX_TOKEN]; } Token;

int isKeyword(const char *s) {
    return strstr("int float if else while return", s) && (s[strlen(s)+1] == ' ' || !s[strlen(s)+1]);
}

void lexicalAnalyzer(FILE *in, FILE *out) {
    char c, t[MAX_TOKEN] = {0};
    Token tokens[1000];
    int ti = 0, si = 0;
    while ((c = fgetc(in)) != EOF && si < 1000) {
        if (isspace(c)) continue;
        if (c == '/') {
            if ((c = fgetc(in)) == '/') while ((c = fgetc(in)) != '\n' && c != EOF);
            else if (c == '*') while ((c = fgetc(in)) != EOF && (c != '*' || fgetc(in) != '/'));
            else ungetc(c, in);
            continue;
        }
        if (isalpha(c)) {
            t[ti++] = c;
            while (isalnum(c = fgetc(in)) && ti < MAX_TOKEN-1) t[ti++] = c;
            t[ti] = 0; tokens[si].type = isKeyword(t) ? KEYWORD : IDENTIFIER;
            strcpy(tokens[si++].value, t); ti = 0; ungetc(c, in);
        } else if (isdigit(c)) {
            t[ti++] = c;
            while (isdigit(c = fgetc(in)) && ti < MAX_TOKEN-1) t[ti++] = c;
            t[ti] = 0; tokens[si].type = NUMBER; strcpy(tokens[si++].value, t); ti = 0; ungetc(c, in);
        } else if (strchr("+-*/=<>!", c)) {
            char op[3] = {c, 0};
            if ((c = fgetc(in)) == '=' && strchr("=<!>", op[0])) op[1] = c; else ungetc(c, in);
            tokens[si].type = OPERATOR; strcpy(tokens[si++].value, op);
        } else if (strchr(";(){},", c)) {
            tokens[si].type = PUNCTUATION; tokens[si].value[0] = c; tokens[si++].value[1] = 0;
        } else fprintf(stderr, "Invalid: %c\n", c);
        printf("%s \n",t);
    }
    for (int i = 0; i < si; i++)
        fprintf(out, "Token %d: %s=%s\n", i+1, 
                tokens[i].type == KEYWORD ? "KEYWORD" : 
                tokens[i].type == IDENTIFIER ? "IDENTIFIER" : 
                tokens[i].type == NUMBER ? "NUMBER" : 
                tokens[i].type == OPERATOR ? "OPERATOR" : "PUNCTUATION", 
                tokens[i].value);
}

int main() {
    FILE *in = fopen("input.c", "r"), *out = fopen("output.txt", "w");
    if (!in || !out) return fprintf(stderr, "File error\n"), 1;
    lexicalAnalyzer(in, out);
    fclose(in); fclose(out);
    return 0;
}
